// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutlinerUtils.h"

#include "ActorTreeItem.h"
#include "ActorFolderTreeItem.h"
#include "ColorOutlinerSettings.h"
#include "Containers/Map.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"

namespace SceneOutlinerFolderUtils
{
	static TMap< FString, FLinearColor > SceneOutlinerPathColors;

	static TMap< FString, FLinearColor > TempPathColors;

	static TMap< UWorld*, FString > MapsOldName;

	static TArray<FString> MapPathsGoingDelete;

	static bool IsTempMap;

	static FString MapPath;

	static bool IsFolderMoved;

	static bool IsCurrentMapRenamed;

	static bool CanDeleteActorsExecute = true;
}

FLinearColor SceneOutlinerFolderUtils::GetOutlinerItemDefaultColor(const bool bIsFolder)
{
	static const FName OutlinerFolderColorName("SceneOutliner.FolderClosed");
	return bIsFolder?
		FAppStyle::Get().GetBrush(OutlinerFolderColorName)->TintColor.GetSpecifiedColor():
		FLinearColor::White;
}

FString SceneOutlinerFolderUtils::GetSectionName()
{
	static const FString SectionName(TEXT("OutlinerItemIconColor"));
	return SectionName;
}

FName SceneOutlinerFolderUtils::GetDefaultContextBaseMenuName()
{
	static const FName DefaultContextBaseMenuName("SceneOutliner.DefaultContextMenuBase");
	//static const FName DefaultContextMenuName("SceneOutliner.DefaultContextMenu");
	return DefaultContextBaseMenuName;
}

FString SceneOutlinerFolderUtils::GetFolderFullPath(const FActorFolderTreeItem* SelectedFolder)
{
	return GetCurrentMapPath().Append(SelectedFolder->GetPath().ToString());
}

FString SceneOutlinerFolderUtils::GetFolderFullPath(const FFolder& Folder)
{
	return GetCurrentMapPath().Append(Folder.GetPath().ToString());
}

FString SceneOutlinerFolderUtils::GetActorFullPath(const FActorTreeItem* SelectedActor)
{
	FString PrefixPath = SelectedActor->Actor->GetLevel()->GetPathName();
	//移除多余后缀
	PrefixPath = PrefixPath.Left(PrefixPath.Find(TEXT(".")));

	//在游戏运行时, 获取到的关卡名有"UEDPIE_0_"前缀, 移除(存在运行时设置及获取颜色的情况)
	//但有没有可能是UEDPIE_1_ , 2? 为避免其余情况 , 在出现UEDPIE_时移除固定长度
	if(const int32 n = PrefixPath.Find(TEXT("UEDPIE_"),ESearchCase::CaseSensitive); n > 0)
	{
		PrefixPath.RemoveAt(n,9);
	}
	
	return PrefixPath.Append(TEXT("/")+SelectedActor->GetGuid().ToString());
}
FString SceneOutlinerFolderUtils::GetActorFullPath(const AActor* InActor)
{
	FString PrefixPath = InActor->GetLevel()->GetPathName();
	PrefixPath = PrefixPath.Left(PrefixPath.Find(TEXT(".")));
	
	if(const int32 n = PrefixPath.Find(TEXT("UEDPIE_"),ESearchCase::CaseSensitive); n > 0)
	{
		PrefixPath.RemoveAt(n,9);
	}
	
	return PrefixPath.Append(TEXT("/")+InActor->GetActorGuid().ToString());
}

bool SceneOutlinerFolderUtils::IsActorInTempMap(const FString& ActorFullPath)
{
	if(GetIsTempMap())
	{
		if(ActorFullPath.StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
		{
			return true;
		}
	}
	return false;
}

TOptional<FLinearColor> SceneOutlinerFolderUtils::GetColorByPath(const FString& InFullPath, const bool bIsFolder)
{
	auto GetPathColorInternal = [](const FString& InPath,const bool bIsFolderInternal) -> TOptional<FLinearColor>
	{
		// See if we have a value cached first
		
		if(const FLinearColor* CachedColor = SceneOutlinerPathColors.Find(InPath);
			CachedColor)
		{
			return *CachedColor;
		}
		
		// Loads the color of folder at the given path from the config
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			// Create a new entry from the config, skip if it's default
			FString ColorStr;
			if(GConfig->GetString(*GetSectionName(), *InPath, ColorStr, GEditorPerProjectIni))
			{
				FLinearColor Color;
				if(Color.InitFromString(ColorStr) && !Color.Equals(GetOutlinerItemDefaultColor(bIsFolderInternal)))
				{
					return SceneOutlinerPathColors.Add(InPath, FLinearColor(Color));
				}
			}
			else
			{
				return SceneOutlinerPathColors.Add(InPath, FLinearColor(GetOutlinerItemDefaultColor(bIsFolderInternal)));
			}
		}
		return TOptional<FLinearColor>();
	};

	// First try and find the color using the given path, as this works correctly for both assets and classes
	TOptional<FLinearColor> FoundColor = GetPathColorInternal(InFullPath,bIsFolder);
	if(FoundColor.IsSet())
	{
		return FoundColor;
	}

	// If that failed, try and use the filename (assets used to use this as their color key, but it doesn't work with classes)
	{
		FString RelativePath;
		if (FPackageName::TryConvertLongPackageNameToFilename(InFullPath / FString(), RelativePath))
		{
			return GetPathColorInternal(RelativePath,bIsFolder);
		}
	}

	return TOptional<FLinearColor>();
}

TOptional<FLinearColor> SceneOutlinerFolderUtils::GetColorByPathTemp(const FString& InTempPath)
{
	auto GetPathColorInternal = [](const FString& InPath) -> TOptional<FLinearColor>
	{
		// See if we have a value cached first
		const FLinearColor* CachedColor = TempPathColors.Find(InPath);
		if(CachedColor)
		{
			return *CachedColor;
		}
		
		return TOptional<FLinearColor>();
	};
	// First try and find the color using the given path, as this works correctly for both assets and classes
	TOptional<FLinearColor> FoundColor = GetPathColorInternal(InTempPath);
	if(FoundColor.IsSet())
	{
		return FoundColor;
	}
	return TOptional<FLinearColor>();
}

void SceneOutlinerFolderUtils::SaveColorWithPath(const FString& InFullPath, TOptional<FLinearColor> InColor,bool bIsFolder)
{
	auto SetPathColorInternal = [](const FString& InPath, FLinearColor InFolderColor)
	{
		// Saves the color of the folder to the config
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			GConfig->SetString(*GetSectionName(), *InPath, *InFolderColor.ToString(), GEditorPerProjectIni);
		}

		// Update the map too
		SceneOutlinerPathColors.Add(InPath, InFolderColor);
	};

	auto RemoveColorInternal = [](const FString& InPath)
	{
		// Remove the color of the folder from the config
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			GConfig->RemoveKey(*GetSectionName(), *InPath, GEditorPerProjectIni);
		}

		// Update the map too
		SceneOutlinerPathColors.Remove(InPath);
	};

	// Remove the color if it's invalid or default
	const bool bRemove = !InColor.IsSet() || InColor->Equals(GetOutlinerItemDefaultColor(bIsFolder));
	if(bRemove)
	{
		RemoveColorInternal(InFullPath);
	}
	else
	{
		SetPathColorInternal(InFullPath, InColor.GetValue());
	}

	// Make sure and remove any colors using the legacy path format
	{
		FString RelativePath;
		if (FPackageName::TryConvertLongPackageNameToFilename(InFullPath / FString(), RelativePath))
		{
			return RemoveColorInternal(RelativePath);
		}
	}
}

void SceneOutlinerFolderUtils::SaveColorWithPathTemp(const FString& InTempPath, TOptional<FLinearColor> InColor, const bool bIsFolder)
{
	// Remove the color if it's invalid or default
	const bool bRemove = !InColor.IsSet() || InColor->Equals(GetOutlinerItemDefaultColor(bIsFolder));
	if(bRemove)
	{
		TempPathColors.Remove(InTempPath);
	}
	else
	{
		TempPathColors.Add(InTempPath, InColor.GetValue());
	}
}

void SceneOutlinerFolderUtils::SetIconColor(TSharedPtr<SWidget> RowWidget, const FLinearColor InColor)
{
	TSharedPtr<SWidget> CurrentWidget = RowWidget;
	if(CurrentWidget->GetChildren()->Num()==0) return;
	/*SHorizontalBox*/
	CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(0);

	if(const UColorOutlinerSettings* Settings = GetDefault<UColorOutlinerSettings>();Settings->bSimultaneouslySettingTextColor)
	{
		SetTextColor(CurrentWidget,InColor);
	}
						
	if(CurrentWidget->GetChildren()->Num()==0) return;
	/*SBox*/
	CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(0);
						
	if(CurrentWidget->GetChildren()->Num()==0) return;
	/*Item_SImage*/
	CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(0);
	if(CurrentWidget->GetType() == FName("SImage"))
	{
		if(TSharedPtr<SImage> Image = StaticCastSharedPtr<SImage>(CurrentWidget))
		{
			Image->SetColorAndOpacity(InColor);
		}
	}
}

void SceneOutlinerFolderUtils::SetTextColor(TSharedPtr<SWidget> HorizontalBox, const FLinearColor InColor)
{
	if(HorizontalBox->GetChildren()->Num() < 2) return;
	TSharedPtr<SWidget> SetTextColorWidget = HorizontalBox->GetChildren()->GetChildAt(1);

	TSharedPtr<SInlineEditableTextBlock> InlineEditableText;
	//folder 
	if(SetTextColorWidget->GetType() == FName("SInlineEditableTextBlock"))
	{
		InlineEditableText = StaticCastSharedPtr<SInlineEditableTextBlock>(SetTextColorWidget);
	}
	//actor
	else
	{
		if(SetTextColorWidget->GetChildren()->Num() == 0) return;
		/*SInlineEditableTextBlock*/
		SetTextColorWidget = SetTextColorWidget->GetChildren()->GetChildAt(0);
	
		//原因未知: StaticCastSharedPtr<SInlineEditableTextBlock>(SetTextColorWidget)总能成功, 即使并非对应类型, 故使用Type先判断避免报错
		if(SetTextColorWidget->GetType() == FName("SInlineEditableTextBlock"))
		{
			InlineEditableText = StaticCastSharedPtr<SInlineEditableTextBlock>(SetTextColorWidget);
		}
	}
	
	if(InlineEditableText.IsValid())
	{
		InlineEditableText->SetColorAndOpacity(InColor);
	}
}

void SceneOutlinerFolderUtils::ClearColorsTemp(){ TempPathColors.Empty();}

void SceneOutlinerFolderUtils::TempToSave(const UWorld* World)
{
	FString PrefixPath = World->GetPathName();
	PrefixPath.RemoveFromEnd(TEXT(".")+World->GetMapName());

	for(const TTuple<FString, FLinearColor>& pair : TempPathColors)
	{
		FString FullPath = PrefixPath;
		FullPath.Append(TEXT("/")+pair.Key);
		
		SaveColorWithPath(FullPath , pair.Value , pair.Key.Len() != 32);
	}
}

void SceneOutlinerFolderUtils::OnPreWorldRename(UWorld* World)
{
	FString PrefixPath = World->GetPathName();
	PrefixPath.RemoveFromEnd(TEXT(".")+World->GetMapName());
	PrefixPath.Append(TEXT("/"));

	MapsOldName.Add(World, PrefixPath);

	/*Is the rename world current open?*/
	SaveIsCurrentMapRenamed(GetCurrentMapPath()==PrefixPath);
}

void SceneOutlinerFolderUtils::OnPostWorldRename(UWorld* World)
{
	FString OldName;
	MapsOldName.RemoveAndCopyValue(World,OldName);

	FString NewName = World->GetPathName();
	NewName.RemoveFromEnd(TEXT(".")+World->GetMapName());
	NewName.Append(TEXT("/"));
	
	/*UpdataCurrentMapPath*/
	if(GetIsCurrentMapRenamed())
	{
		SaveCurrentMapPath(NewName);
	}
	
	if(FPaths::FileExists(GEditorPerProjectIni))
	{
		TArray<FString> Result;
		GConfig->GetSection(*GetSectionName(),Result,GEditorPerProjectIni);
		for(const FString CurrentPair : Result)
		{
			if(CurrentPair.StartsWith(OldName,ESearchCase::CaseSensitive))
			{
				const FString OldPath = CurrentPair.Left(CurrentPair.Find(TEXT("=")));
				const FString FSColor = CurrentPair.RightChop(CurrentPair.Find(TEXT("="))+1);

				FString NewPath = OldPath;
				NewPath.RemoveFromStart(OldName,ESearchCase::CaseSensitive);
				NewPath = NewName + NewPath;
				
				GConfig->RemoveKey(*GetSectionName(), *OldPath, GEditorPerProjectIni);
				GConfig->SetString(*GetSectionName(), *NewPath, *FSColor, GEditorPerProjectIni);
				
				FLinearColor FLColor;
				if(!SceneOutlinerPathColors.RemoveAndCopyValue(OldPath,FLColor))
				{
					FLColor.InitFromString(FSColor);
				}
				SceneOutlinerPathColors.Add(NewPath,FLColor);
			}
		}
	}
}

void SceneOutlinerFolderUtils::OnWorldPreDelete(const TArray<UObject*>& Objects)
{
	MapPathsGoingDelete.Empty();
	
	for(const UObject* Object : Objects)
	{
		if(Cast<UWorld>(Object))
		{
			FString PrefixPath = Object->GetPathName();
			PrefixPath.RemoveFromEnd(TEXT(".")+Object->GetName());
			PrefixPath.Append(TEXT("/"));
			
			MapPathsGoingDelete.Add(PrefixPath);
		}
	}
}

void SceneOutlinerFolderUtils::OnWorldDeleted()
{
	for(const FString Path : MapPathsGoingDelete)
	{
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			TArray<FString> Result;
			GConfig->GetSection(*GetSectionName(),Result,GEditorPerProjectIni);
			for(const FString CurrentPair : Result)
			{
				if(CurrentPair.StartsWith(Path,ESearchCase::CaseSensitive))
				{
					const FString FullPath = CurrentPair.Left(CurrentPair.Find(TEXT("=")));
					GConfig->RemoveKey(*GetSectionName(), *FullPath, GEditorPerProjectIni);
					if(SceneOutlinerPathColors.Contains(FullPath))
					{
						SceneOutlinerPathColors.Remove(FullPath);
					}
				}
			}
		}
	}
}

void SceneOutlinerFolderUtils::UpdateFolderFullPath(const FFolder& Source, const FFolder& Dest)
{
	FLinearColor SColor;
	if(GetIsTempMap())
	{
		const FString SourcePath = Source.GetPath().ToString();
		const FString DestPath = Dest.GetPath().ToString();

		if(TempPathColors.RemoveAndCopyValue(SourcePath,SColor))
		{
			TempPathColors.Add(DestPath,SColor);
		}
	}
	else
	{
		const FString SourcePath = GetFolderFullPath(Source);
		const FString DestPath = GetFolderFullPath(Dest);

		if(SceneOutlinerPathColors.RemoveAndCopyValue(SourcePath,SColor))
		{
			SceneOutlinerPathColors.Add(DestPath,SColor);
		}
	
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			FString FColor;
			if(GConfig->GetString(*GetSectionName(), *SourcePath, FColor, GEditorPerProjectIni))
			{
				GConfig->RemoveKey(*GetSectionName(), *SourcePath, GEditorPerProjectIni);
				GConfig->SetString(*GetSectionName(), *DestPath, *FColor, GEditorPerProjectIni);
			}
		}
	}
}

void SceneOutlinerFolderUtils::DeleteFolderFullPath(const FFolder& Folder)
{
	GetIsTempMap() ?
		DeleteFullPathFromTemp(Folder.GetPath().ToString()):
		DeleteFullPathFromConfig(GetFolderFullPath(Folder));
}

void SceneOutlinerFolderUtils::DeleteActorFullPath(const AActor* InActor)
{
	//当处于PIE(运行时), 删除的actor会在停止运行时被还原, 故不清理颜色
	if(InActor->GetWorld()->IsPlayInEditor()) return;
	
	IsActorInTempMap(GetActorFullPath(InActor)) ?
		DeleteFullPathFromTemp(InActor->GetActorGuid().ToString()):
		DeleteFullPathFromConfig(GetActorFullPath(InActor));
}

void SceneOutlinerFolderUtils::SaveIsTempMap(const bool IsTemp){ IsTempMap = IsTemp;}

bool SceneOutlinerFolderUtils::GetIsTempMap(){ return IsTempMap;}

void SceneOutlinerFolderUtils::SaveCurrentMapPath(const FString& InMapPath){ MapPath = InMapPath;}

FString SceneOutlinerFolderUtils::GetCurrentMapPath(){ return MapPath;}

void SceneOutlinerFolderUtils::SaveIsFolderMoved(const bool IsMoved){ IsFolderMoved = IsMoved;}

bool SceneOutlinerFolderUtils::GetIsFolderMoved(){ return IsFolderMoved;}

void SceneOutlinerFolderUtils::SaveIsCurrentMapRenamed(const bool bInIsCurrentMap){IsCurrentMapRenamed = bInIsCurrentMap;}

bool SceneOutlinerFolderUtils::GetIsCurrentMapRenamed(){return IsCurrentMapRenamed;}

void SceneOutlinerFolderUtils::SetCanDeleteActorsExecute(const bool bCanDeleteActorsExecute){CanDeleteActorsExecute = bCanDeleteActorsExecute;}

bool SceneOutlinerFolderUtils::GetCanDeleteActorsExecute(){return CanDeleteActorsExecute;}

void SceneOutlinerFolderUtils::DeleteFullPathFromConfig(const FString& InPath)
{
	if(FPaths::FileExists(GEditorPerProjectIni))
	{
		FString FColor;
		if(GConfig->GetString(*GetSectionName(), *InPath, FColor, GEditorPerProjectIni))
		{
			GConfig->RemoveKey(*GetSectionName(), *InPath, GEditorPerProjectIni);
		}
	}
	if(SceneOutlinerPathColors.Contains(InPath))
	{
		SceneOutlinerPathColors.Remove(InPath);
	}
}

void SceneOutlinerFolderUtils::DeleteFullPathFromTemp(const FString& InPath)
{
	if(TempPathColors.Contains(InPath))
	{
		TempPathColors.Remove(InPath);
	}
}

void SceneOutlinerFolderUtils::ClearCache()
{
	SceneOutlinerPathColors.Empty();
	TempPathColors.Empty();
	MapsOldName.Empty();
	MapPathsGoingDelete.Empty();
	MapPath.Empty();
}