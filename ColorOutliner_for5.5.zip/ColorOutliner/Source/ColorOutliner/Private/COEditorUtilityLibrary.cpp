// Fill out your copyright notice in the Description page of Project Settings.


#include "COEditorUtilityLibrary.h"
#include "LevelEditor.h"
#include "ColorOutlinerUtils.h"
#include "SSceneOutliner.h"

#if WITH_EDITOR

FLinearColor UCOEditorUtilityLibrary::GetActorItemColor(const AActor* Actor)
{
	const FString FullPath = SceneOutlinerFolderUtils::GetActorFullPath(Actor);
	
	TOptional<FLinearColor> TColor = SceneOutlinerFolderUtils::IsActorInTempMap(FullPath)?
				SceneOutlinerFolderUtils::GetColorByPathTemp(Actor->GetActorGuid().ToString()) : SceneOutlinerFolderUtils::GetColorByPath(FullPath,false);

	if(TColor.IsSet())
	{
		if(!TColor.GetValue().Equals(SceneOutlinerFolderUtils::GetOutlinerItemDefaultColor(false)))
		{
			return TColor.GetValue();
		}
	}
	
	return FLinearColor::White;
}

void UCOEditorUtilityLibrary::SetActorItemColor(const AActor* Actor, const FLinearColor Color,const bool Refresh)
{
	const FString FullPath = SceneOutlinerFolderUtils::GetActorFullPath(Actor);
	
	SceneOutlinerFolderUtils::IsActorInTempMap(FullPath)?
		SceneOutlinerFolderUtils::SaveColorWithPathTemp(Actor->GetActorGuid().ToString(),Color,false):
								SceneOutlinerFolderUtils::SaveColorWithPath(FullPath,Color,false);

	if(Refresh)
	{
		RefreshSceneOutliners();
	}
}

void UCOEditorUtilityLibrary::ClearActorItemColor(const AActor* Actor, const bool Refresh)
{
	const FString FullPath = SceneOutlinerFolderUtils::GetActorFullPath(Actor);
	
	SceneOutlinerFolderUtils::IsActorInTempMap(FullPath)?
		SceneOutlinerFolderUtils::DeleteFullPathFromTemp(Actor->GetActorGuid().ToString()):
		SceneOutlinerFolderUtils::DeleteFullPathFromConfig(FullPath);

	if(Refresh)
	{
		RefreshSceneOutliners();
	}
}

void UCOEditorUtilityLibrary::RefreshSceneOutliners()
{
	const FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		
	for(const TWeakPtr<ISceneOutliner>& Outliner : LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners())
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
}
	
#endif