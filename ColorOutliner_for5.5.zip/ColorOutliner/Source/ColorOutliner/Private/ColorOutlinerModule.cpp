// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutlinerModule.h"

#include "LevelEditor.h"
#include "SceneOutlinerModule.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerMenuContext.h"
#include "SSceneOutliner.h"
#include "ToolMenu.h"
#include "ToolMenuDelegates.h"
#include "ToolMenuEntry.h"
#include "ToolMenuSection.h"
#include "ToolMenus.h"
#include "Widgets/Colors/SColorPicker.h"
#include "ActorFolderTreeItem.h"
#include "ActorTreeItem.h"
#include "ColorOutlinerSettings.h"
#include "FSOItemLabelColumnReplace.h"
//#include "SOutlinerTreeView.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Editor.h"
#include "EditorActorFolders.h"
#include "EditorLevelUtils.h"
#include "Subsystems/EditorActorSubsystem.h"

#define LOCTEXT_NAMESPACE "FColorOutlinerModule"

namespace OFUtils = SceneOutlinerFolderUtils;

void FColorOutlinerModule::StartupModule()
{
	RegisterOnMapRename();
	RegisterOnMapDeleted();
	RegisterOnMapChanged();
	RegisterOnFolderOperate();
	RegisterOnActorDelete();
	RegisterOnMoveActorsToLevel();
	RegisterOnBlueprintCompile();
	RegisterOutlinerItemLabelColumn();
	RegisterOutlinerContextMenuExtend();
	RegisterTintedFilter();
	RegisterOnSettingsChanged();
}

void FColorOutlinerModule::ShutdownModule()
{
	/*UnregisterOnMapRename*/
	if(OnPreWorldRenameHandle.IsValid()){FWorldDelegates::OnPreWorldRename.Remove(OnPreWorldRenameHandle);}
	if(OnPostWorldRenameHandle.IsValid()){FWorldDelegates::OnPostWorldRename.Remove(OnPostWorldRenameHandle);}
	
	/*UnregisterOnMapDeleted*/
	if(OnAssetsPreDeleteHandle.IsValid()){FEditorDelegates::OnAssetsPreDelete.Remove(OnAssetsPreDeleteHandle);}
	if(OnAssetsDeletedHandle.IsValid()){FEditorDelegates::OnAssetsDeleted.Remove(OnAssetsDeletedHandle);}
	
	/*UnregisterOnMapChanged*/
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	if(OnMapChangedHandle.IsValid()){LevelEditorModule.OnMapChanged().Remove(OnMapChangedHandle);}
	
	/*UnregisterOnFolderOperate*/
	if(OnFolderMovedHandle.IsValid()){FActorFolders::OnFolderMoved.Remove(OnFolderMovedHandle);}
	if(OnFolderDeletedHandle.IsValid()){FActorFolders::OnFolderDeleted.Remove(OnFolderDeletedHandle);}

	if(OnLevelActorDeleted.IsValid()){
		if(GEngine!=nullptr){
			GEngine->OnLevelActorDeleted().Remove(OnLevelActorDeleted);}}

	if(OnMoveActorsToLevel.IsValid()){UEditorLevelUtils::OnMoveActorsToLevelEvent.Remove(OnMoveActorsToLevel);}

	if(GEditor)
	{
		if(OnBlueprintPreCompile.IsValid()){GEditor->OnBlueprintPreCompile().Remove(OnBlueprintPreCompile);}
		if(OnBlueprintCompiled.IsValid()){GEditor->OnBlueprintCompiled().Remove(OnBlueprintCompiled);}
	}
	
	/*UnregisterOutlinerItemLabelColumn*/
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSOItemLabelColumnReplace>();

	if(OnSettingsChangedHandle.IsValid()){FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.Remove(OnSettingsChangedHandle);}

	OFUtils::ClearCache();
}

void FColorOutlinerModule::RegisterOnMapRename()
{
	OnPreWorldRenameHandle = FWorldDelegates::OnPreWorldRename.AddLambda([](UWorld* World, const TCHAR* InName, UObject* NewOuter, ERenameFlags Flags, bool& bShouldFailRename)
	{
		OFUtils::OnPreWorldRename(World);
	});

	OnPostWorldRenameHandle = FWorldDelegates::OnPostWorldRename.AddLambda([](UWorld* World)
	{
		OFUtils::OnPostWorldRename(World);
	});
}

void FColorOutlinerModule::RegisterOnMapDeleted()
{
	OnAssetsPreDeleteHandle = FEditorDelegates::OnAssetsPreDelete.AddLambda([](const TArray<UObject*>& Objects)
	{
		OFUtils::OnWorldPreDelete(Objects);
	});
	
	OnAssetsDeletedHandle = FEditorDelegates::OnAssetsDeleted.AddLambda([](const TArray<UClass*>& Classes)
	{
		OFUtils::OnWorldDeleted();
	});
}

void FColorOutlinerModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedHandle = LevelEditorModule.OnMapChanged().AddLambda([&](const UWorld* World, const EMapChangeType MapChangeType)
	{
		FString NowMapPath;
		switch (MapChangeType)
		{
			case EMapChangeType::LoadMap:
				/*Template or existing*/
				NowMapPath = World->GetPathName();
				if(NowMapPath.StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
				{
					OFUtils::SaveIsTempMap(true);
				}
				else
				{
					OFUtils::SaveIsTempMap(false);
					NowMapPath.RemoveFromEnd(TEXT(".")+World->GetMapName());
					OFUtils::SaveCurrentMapPath(NowMapPath);
				}
			break;
		
			case EMapChangeType::NewMap:
				/*Empty level*/
				OFUtils::SaveIsTempMap(true);
			break;
		
			case EMapChangeType::SaveMap:
				/*Is template or empty level to save?*/
				if(OFUtils::GetIsTempMap())
				{
					OFUtils::TempToSave(World);
				}
			break;
		
			case EMapChangeType::TearDownWorld:
				/*Clear cache*/
				OFUtils::SaveCurrentMapPath(FString());
				OFUtils::ClearColorsTemp();
			break;
		}
	});
}

void FColorOutlinerModule::RegisterOnFolderOperate()
{
	OnFolderMovedHandle = FActorFolders::OnFolderMoved.AddLambda([](const UWorld& World, const FFolder& Source, const FFolder& Dest)
	{
		OFUtils::SaveIsFolderMoved(true);
		
		//运行时, 移动操作会在停止后被还原, 运行时移动应复制一份颜色,但较复杂且该操作几乎不可能被执行, 且影响不大. 故忽略
		if(World.IsPlayInEditor()) return;
		
		OFUtils::UpdateFolderFullPath(Source,Dest);
	});
	
	OnFolderDeletedHandle = FActorFolders::OnFolderDeleted.AddLambda([](const  UWorld& World, const FFolder& DeletedFolder )
	{
		if(!OFUtils::GetIsFolderMoved())
		{
			//运行时, 删除操作会在停止后被还原, 故不清除颜色
			if(World.IsPlayInEditor()) return;
			
			/*Not move,means delete*/
			OFUtils::DeleteFolderFullPath(DeletedFolder);
		}
		else
		{
			OFUtils::SaveIsFolderMoved(false);
		}
	});
}

void FColorOutlinerModule::RegisterOnActorDelete()
{
	if(GEngine==nullptr) return;
	OnLevelActorDeleted = GEngine->OnLevelActorDeleted().AddLambda([](const AActor* ActorDeleted)
	{
		if(OFUtils::GetCanDeleteActorsExecute())
		{
			OFUtils::DeleteActorFullPath(ActorDeleted);
		}
	});
}

void FColorOutlinerModule::RegisterOnMoveActorsToLevel()
{
	/*
	 *When executing the movement of Actors to another streaming level,
	 *the actual process involves deleting the original actors and regenerating identical actors in the new level.
	 *However, the Guids of the new actors will be refreshed.
	 */
	OnMoveActorsToLevel = UEditorLevelUtils::OnMoveActorsToLevelEvent.AddLambda([](const TArray<AActor*>& ActorsToDelete, const ULevel* DestLevel)
	{
		for(AActor* CurrentActorToDelete : ActorsToDelete)
		{
			if(CurrentActorToDelete==nullptr) continue;
			/*
			 *Although they are not the same AActor objects programmatically, their properties need to be copied completely, such as Tags.
			 *Therefore, during the deletion process,the item's color information is saved into the Tags,
			 *and upon generation, it is retrieved and the saved Tag is removed.
			 */
			const FString FullPath = OFUtils::GetActorFullPath(CurrentActorToDelete);
			
			TOptional<FLinearColor> TColor = OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::GetColorByPathTemp(CurrentActorToDelete->GetActorGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
			
			if(TColor.IsSet())
			{
				if(!TColor.GetValue().Equals(OFUtils::GetOutlinerItemDefaultColor(false)))
				{
					FName FNColor = FName(FString(TColor->ToString()));
					
					CurrentActorToDelete->Tags.AddUnique(FName(OFUtils::GetSectionName()));
					CurrentActorToDelete->Tags.AddUnique(FNColor);
					/*
					 * There is no need to explicitly perform a cleanup operation on the config,
					 * as the OnMoveActorsToLevelEvent automatically triggers a OnActorDeleted callback.
					 */
				}
			}
		}
		/*
		 * The retrieval process must be delayed for one frame since the actor accessed in the current frame is still the original one,
		 * and any operations performed on it will be carried out before destruction.
		 * After a frame delay, the Tags will be read, and the color information will be saved to the configuration.
		 */
		FTimerManager& TimerManager = DestLevel->GetWorld()->GetTimerManager();
		TimerManager.SetTimerForNextTick(
			FTimerDelegate::CreateLambda([]()
			{
				TArray<AActor*> ActorsToAdd= GEditor->GetEditorSubsystem<UEditorActorSubsystem>()->GetSelectedLevelActors();
				for(AActor* CurrentActorToAdd : ActorsToAdd)
				{
					if(CurrentActorToAdd==nullptr) continue;
					
					int FindIndex;
					if(CurrentActorToAdd->Tags.Find(FName(OFUtils::GetSectionName()),FindIndex))
					{
						if(FindIndex+2 == CurrentActorToAdd->Tags.Num())
						{
							FLinearColor FLColor;
							FLColor.InitFromString(CurrentActorToAdd->Tags[FindIndex+1].ToString());

							const FString FullPath = OFUtils::GetActorFullPath(CurrentActorToAdd);
							
							OFUtils::IsActorInTempMap(FullPath)?
								OFUtils::SaveColorWithPathTemp(CurrentActorToAdd->GetActorGuid().ToString(),FLColor,false):
								OFUtils::SaveColorWithPath(FullPath,FLColor,false);
							
							CurrentActorToAdd->Tags.SetNum(FindIndex);
						}
					}
				}
			})
		);
	});
}

void FColorOutlinerModule::RegisterOnBlueprintCompile()
{
	if(!GEditor) return;
	
	OnBlueprintPreCompile = GEditor->OnBlueprintPreCompile().AddLambda([](const UBlueprint* Blueprint)
	{
		OFUtils::SetCanDeleteActorsExecute(false);
	});

	OnBlueprintCompiled = GEditor->OnBlueprintCompiled().AddLambda([]()
	{
		OFUtils::SetCanDeleteActorsExecute(true);
	});
}

void FColorOutlinerModule::RegisterOutlinerItemLabelColumn()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSceneOutlinerItemLabelColumn>();
	
	//SceneOutlinerModule.RegisterDefaultColumnType<FSOItemLabelColumnReplace>(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 6));
	SceneOutlinerModule.RegisterDefaultColumnType< FSOItemLabelColumnReplace >(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 10, FCreateSceneOutlinerColumn(), false, TOptional<float>(), FSceneOutlinerBuiltInColumnTypes::Label_Localized()));
}

void FColorOutlinerModule::RegisterOutlinerContextMenuExtend()
{
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(OFUtils::GetDefaultContextBaseMenuName());
	
	Menu->AddDynamicSection("SetColorSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		const USceneOutlinerMenuContext* Context = InMenu->FindContext<USceneOutlinerMenuContext>();
		if (!Context)
		{
			return;
		}
		FToolMenuSection& Section = InMenu->FindOrAddSection("SceneOutlinerItemOptions");
		Section.Label = LOCTEXT("ItemOptionsLabel", "Item Options");
		
		SelectedSceneOutliner = Context->SceneOutliner;
		const FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		SceneOutliners = LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners();
		
		/*select and only select folder*/
		if (Context->NumSelectedItems > 0 && Context->NumSelectedFolders == Context->NumSelectedItems)
        {
			ExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("SetColorTooltip_Folder", "Sets the color this folder should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerFolderExecutePickColor ) )
				);
			bool bHasAnyItemSetColor = false;
			for(const FSceneOutlinerTreeItemPtr& Item : ExecuteItems)
			{
				if(const FActorFolderTreeItem* SelectedFolder = Item->CastTo<FActorFolderTreeItem>())
				{
					const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
		
					const TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
					OFUtils::GetColorByPathTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetColorByPath(FullPath,true);
					
					if (Color.IsSet())
					{
						if(!Color->Equals(OFUtils::GetOutlinerItemDefaultColor(true)))
						{
							bHasAnyItemSetColor = true;
							break;
						}
					}
				}
			}
			if(bHasAnyItemSetColor)
			{
				Section.AddMenuEntry(
					"OutlinerClearColor",
					LOCTEXT("OutlinerClearColor", "Clear Color"),
					LOCTEXT("ClearColorTooltip_Folder", "Resets the color this folder appears as."),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerFolderExecuteResetColor ))
					);
			}
        }
		/*only select actors*/
		else if(Context->NumSelectedItems > 0 && Context->NumSelectedFolders == 0 && Context->NumWorldsSelected == 0)
		{
			ExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("SetColorTooltip_Actor", "Sets the color this actor icon should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerActorExecutePickColor ) )
				);
			bool bHasAnyItemSetColor = false;
			for(const FSceneOutlinerTreeItemPtr& Item : ExecuteItems)
			{
				if(const FActorTreeItem* SelectedActor = Item->CastTo<FActorTreeItem>())
				{
					const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
		
					const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
					OFUtils::GetColorByPathTemp(SelectedActor->GetGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
					
					if (Color.IsSet())
					{
						if(!Color->Equals(OFUtils::GetOutlinerItemDefaultColor(false)))
						/*return folder color,for actor item,as same*/
						{
							bHasAnyItemSetColor = true;
							break;
						}
					}
				}
			}
			if(bHasAnyItemSetColor)
			{
				Section.AddMenuEntry(
					"OutlinerClearColor",
					LOCTEXT("OutlinerClearColor", "Clear Color"),
					LOCTEXT("ClearColorTooltip_Actor", "Resets the color this actor icon appears as."),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerActorExecuteResetColor ))
					);
			}
		}
		else
		{
			SceneOutliners.Empty();
			ExecuteItems.Empty();
		}
	}));
}

void FColorOutlinerModule::OutlinerFolderExecutePickColor()
{
	// Spawn a color picker, so the user can select which color they want
	FLinearColor InitialColor = OFUtils::GetOutlinerItemDefaultColor(true);
	
	// Make sure an color entry exists for all the paths, otherwise they won't update in realtime with the widget color
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(const FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
            
			TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
				OFUtils::GetColorByPathTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetColorByPath(FullPath,true);
			
			if (Color.IsSet())
			{
				if(!Color->Equals(InitialColor))
				{
					// Default the color to the first valid entry
					InitialColor = Color.GetValue();
					break;
				}
			}
		}
	}
/*in 5.1.x*/
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 1
	FColorPickerArgs PickerArgs = FColorPickerArgs();
	PickerArgs.InitialColorOverride = InitialColor;
	PickerArgs.OnColorCommitted = FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,true);
	
/*> 5.1.x*/
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION > 1
	FColorPickerArgs PickerArgs = FColorPickerArgs(InitialColor, FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,true));
#endif
	
	PickerArgs.bIsModal = false;
	//PickerArgs.ParentWidget = ParentContent.Pin();

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OutlinerActorExecutePickColor()
{
	// Spawn a color picker, so the user can select which color they want
	FLinearColor InitialColor = OFUtils::GetOutlinerItemDefaultColor(false);
	
	// Make sure an color entry exists for all the paths, otherwise they won't update in realtime with the widget color
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(const FActorTreeItem* SelectedActor = SelectedItem->CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
			
			const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::GetColorByPathTemp(SelectedActor->GetGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
			if (Color.IsSet())
			{
				if(!Color->Equals(OFUtils::GetOutlinerItemDefaultColor(false)))
				{
					// Default the color to the first valid entry
					InitialColor = Color.GetValue();
					break;
				}
			}
		}
	}
	
	/*in 5.1.x*/
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 1
	FColorPickerArgs PickerArgs = FColorPickerArgs();
	PickerArgs.InitialColorOverride = InitialColor;
	PickerArgs.OnColorCommitted = FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,false);
	
	/*> 5.1.x*/
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION > 1
	FColorPickerArgs PickerArgs = FColorPickerArgs(InitialColor, FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,false));
#endif
	
	PickerArgs.bIsModal = false;
	//PickerArgs.ParentWidget = ParentContent.Pin();

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OnLinearColorValueChanged(const FLinearColor InColor,bool bIsFolder)
{
	bIsFolder ? OnFolderColorClicked(InColor) : OnActorColorClicked(InColor);
}

FReply FColorOutlinerModule::OnFolderColorClicked(const FLinearColor InColor)
{
	for(const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(const FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			OFUtils::GetIsTempMap()?
				OFUtils::SaveColorWithPathTemp(SelectedFolder->GetPath().ToString(),InColor,true):
				OFUtils::SaveColorWithPath(OFUtils::GetFolderFullPath(SelectedFolder),InColor,true);
		}
	}
	RefreshSceneOutliner();
	return FReply::Handled();
}

FReply FColorOutlinerModule::OnActorColorClicked(const FLinearColor InColor)
{
	for(const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(const FActorTreeItem* SelectedActor = SelectedItem->CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
			
			OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::SaveColorWithPathTemp(SelectedActor->GetGuid().ToString(),InColor,false):
				OFUtils::SaveColorWithPath(FullPath,InColor,false);
		}
	}
	RefreshSceneOutliner();
	return FReply::Handled();
}

void FColorOutlinerModule::OutlinerFolderExecuteResetColor()
{
	for(const FSceneOutlinerTreeItemPtr& Item : ExecuteItems)
	{
		if(const FActorFolderTreeItem* SelectedFolder = Item->CastTo<FActorFolderTreeItem>())
		{
			OFUtils::GetIsTempMap()?
				OFUtils::DeleteFullPathFromTemp(SelectedFolder->GetPath().ToString()):
				OFUtils::DeleteFullPathFromConfig(OFUtils::GetFolderFullPath(SelectedFolder));
		}
	}
	RefreshSceneOutliner();
}

void FColorOutlinerModule::OutlinerActorExecuteResetColor()
{
	for(const FSceneOutlinerTreeItemPtr& Item : ExecuteItems)
	{
		if(const FActorTreeItem* SelectedActor = Item->CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
			OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::DeleteFullPathFromTemp(SelectedActor->GetGuid().ToString()):
				OFUtils::DeleteFullPathFromConfig(FullPath);
		}
	}
	RefreshSceneOutliner();
}

void FColorOutlinerModule::RefreshSceneOutliner()
{
	for(const TWeakPtr<ISceneOutliner>& Outliner : SceneOutliners)
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
}

void FColorOutlinerModule::RegisterTintedFilter()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));

	//构建主入口
	TSharedPtr<FFilterCategory> FilterCategory = MakeShared<FFilterCategory>(
		LOCTEXT("ColouredFilter","Coloured Filter")/*主入口名称*/,
		LOCTEXT("ColouredFilterTooltip","In the Actor filter, whenever an actor is displayed, its folder hierarchy is also shown, regardless of whether the folder is colored or not.In the Folder filter, similarly, when a folder is displayed, all of its direct actor children will be shown as well.")
		);/*主入口Tooltip*/

	//过滤actor的规则, 返回未着色actor
	auto TintedActorsFilterRule = [](const ISceneOutlinerTreeItem& Item,const bool ShowTinted)->bool
	{
		if(const FActorTreeItem* ActorItem = Item.CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(ActorItem);
			
			const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
			OFUtils::GetColorByPathTemp(ActorItem->GetGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
				
			if (Color.IsSet())
			{
				//ShowTinted为真:需显示着色actor, color不等于默认颜色时返回真.
				//ShowTinted为假:需显示未着色actor, color等于默认颜色时返回真.
				return ShowTinted == !Color->Equals(OFUtils::GetOutlinerItemDefaultColor(false));
			}
			//颜色未设置, 可能是默认颜色
			return !ShowTinted;
		}
		//cast失败, 可能是folder, 一律返回false
		return false;
	};

	//过滤器1, 搭配过滤规则1
	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> ColouredActorsFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Coloured Actors")),  /*在代码中的命名*/
		LOCTEXT("ColouredActors","Coloured Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedActorsFilterRule(Item,true); /*过滤规则*/
			})
		);
	
	//未着色actors过滤器
	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> UncolouredActorsFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Uncoloured Actors")),  /*在代码中的命名*/
		LOCTEXT("UncolouredActors","Uncoloured Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedActorsFilterRule(Item,false);
			})
		);

	//注册所有过滤器 @todo: 函数已废弃建议更新, 但新的函数没有导出, 无定义, 版本更新后检查是否更新代码
	LevelEditorModule.AddCustomFilterToOutliner(ColouredActorsFilter);
	LevelEditorModule.AddCustomFilterToOutliner(UncolouredActorsFilter);


	//folder着色过滤, 仍过滤actor, 但根据其folder着色而非自身
	auto TintedFoldersActorsFilterRule = [](const ISceneOutlinerTreeItem& Item,const bool ShowTinted)->bool
	{
		if(const FActorTreeItem* ActorItem = Item.CastTo<FActorTreeItem>())
		{
			const FFolder& ActorFolder = ActorItem->Actor->GetFolder();
			//const FString ActorFullPath = OFUtils::GetActorFullPath(ActorItem);
			const FString FolderFullPath = OFUtils::GetFolderFullPath(ActorFolder);
			
			TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
				OFUtils::GetColorByPathTemp(ActorFolder.GetPath().ToString()) : OFUtils::GetColorByPath(FolderFullPath,true);

			if (Color.IsSet())
			{
				//ShowTinted为真:需显示着色actor, color不等于默认颜色时返回真.
				//ShowTinted为假:需显示未着色actor, color等于默认颜色时返回真.
				return ShowTinted == !Color->Equals(OFUtils::GetOutlinerItemDefaultColor(true));
			}
			//颜色未设置, 可能是默认颜色
			return !ShowTinted;
		}
		//cast失败, 可能是folder, 一律返回false(actor显示将强制其folder显示
		return false;
	};

	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> ColouredFoldersFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Coloured Folders Actors")),  /*在代码中的命名*/
		LOCTEXT("ColouredFoldersActors","Coloured Folders Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedFoldersActorsFilterRule(Item,true);
			})
		);
	
	const TSharedRef<FGenericFilter<const ISceneOutlinerTreeItem&>> UncolouredFoldersFilter = MakeShared<FGenericFilter<const ISceneOutlinerTreeItem&>>(
		FilterCategory,
		FString(TEXT("Uncoloured Folders Actors")),  /*在代码中的命名*/
		LOCTEXT("UncolouredFoldersActors","Uncoloured Folders Actors"), /*过滤器显示的命名*/
		FGenericFilter<const ISceneOutlinerTreeItem&>::FOnItemFiltered::CreateLambda([&](const ISceneOutlinerTreeItem& Item)->bool
			{
				return TintedFoldersActorsFilterRule(Item,false);
			})
		);

	LevelEditorModule.AddCustomFilterToOutliner(ColouredFoldersFilter);
	LevelEditorModule.AddCustomFilterToOutliner(UncolouredFoldersFilter);
}

void FColorOutlinerModule::RegisterOnSettingsChanged()
{
	OnSettingsChangedHandle = FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.AddLambda([]()
	{
		//这里不调用FColorOutlinerModule::RefreshSceneOutliner(), 因为在设置选项时, SceneOutliners可能还未初始化, 直接获取AllSceneOutliners为佳
		const FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		
		for(const TWeakPtr<ISceneOutliner>& Outliner : LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners())
		{
			if(Outliner.Pin().IsValid())
			{
				Outliner.Pin()->FullRefresh();
			}
		}
	});
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FColorOutlinerModule, ColorOutliner)