// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "COEditorUtilityLibrary.generated.h"

/**
 * 
 */
UCLASS()
class COLOROUTLINER_API UCOEditorUtilityLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

#if WITH_EDITOR
	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "ColorOutlinerUtility")
	static FLinearColor GetActorItemColor(const AActor* Actor);

	/**
	 * @param Refresh Should the outline be refreshed immediately? If not, the item colors will be refreshed the next time they appear. During loop operations, you can uncheck this option and call "RefreshSceneOutliners" once after the loop ends to save overhead.
	 */
	UFUNCTION(BlueprintCallable, Category = "ColorOutlinerUtility")
	static void SetActorItemColor(const AActor* Actor,const FLinearColor Color = FLinearColor::White,const bool Refresh = true);

	/**
	 * @param Refresh Should the outline be refreshed immediately? If not, the item colors will be refreshed the next time they appear. During loop operations, you can uncheck this option and call "RefreshSceneOutliners" once after the loop ends to save overhead.
	 */
	UFUNCTION(BlueprintCallable, Category = "ColorOutlinerUtility")
	static void ClearActorItemColor(const AActor* Actor,const bool Refresh = true);

	/**
	 * Refresh the outlines to display the latest item colors.
	 */
	UFUNCTION(BlueprintCallable, Category = "ColorOutlinerUtility")
	static void RefreshSceneOutliners();
#endif

};
